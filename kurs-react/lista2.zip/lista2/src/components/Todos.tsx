import React from "react";
import ToDoElement from "./ToDoElement";

interface TodosProps {
  tasks: { task: string; done: boolean }[];
  setTasks: React.Dispatch<
    React.SetStateAction<{ task: string; done: boolean }[]>
  >;
  search: string;
  filter: string;
}

const Todos: React.FC<TodosProps> = ({ tasks, setTasks, search, filter }) => {
  if (tasks.length === 0) {
    return <p className="font-light text-lg text-gray-500">No tasks found.</p>;
  }
  return (
    <ul className="w-full px-4 flex flex-col gap-y-4">
      {tasks.map((task, index) => {
        if (
          (search !== "" &&
            !task.task.toLowerCase().includes(search.toLowerCase())) ||
          (filter === "done" && !task.done) ||
          (filter === "undone" && task.done)
        ) {
          return null;
        }
        return (
          <ToDoElement
            index={index}
            task={task}
            tasks={tasks}
            setTasks={setTasks}
          />
        );
      })}
    </ul>
  );
};

export default Todos;
