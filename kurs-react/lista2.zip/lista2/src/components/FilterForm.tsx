import React from "react";

interface FilterFormProps {
  search: string;
  handleSearch: (e: React.ChangeEvent<HTMLInputElement>) => void;
  filter: string;
  handleFilter: (e: React.ChangeEvent<HTMLSelectElement>) => void;
}

const FilterForm: React.FC<FilterFormProps> = ({
  search,
  handleSearch,
  filter,
  handleFilter,
}) => {
  return (
    <div className="flex justify-around w-full">
      <input
        type="text"
        placeholder="Search"
        value={search}
        onChange={handleSearch}
        className="p-2 w-1/2 rounded-lg"
      />

      <select value={filter} onChange={handleFilter} className="p-2 rounded-lg cursor-pointer">
        <option value="all">All</option>
        <option value="done">Done</option>
        <option value="undone">Undone</option>
      </select>
    </div>
  );
};

export default FilterForm;
