import React, { useState } from "react";

interface TodoFormProps {
  handleSubmit: (e: React.FormEvent<HTMLFormElement>, value: string) => void;
}

const TodoForm: React.FC<TodoFormProps> = ({ handleSubmit }) => {
  const [value, setValue] = useState("");
  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    handleSubmit(e, value);
    setValue("");
  };

  return (
    <form onSubmit={onSubmit} className="flex flex-row gap-x-2 w-full">
      <input
        type="text"
        placeholder="Add Task Here..."
        className="border-black-300 border-2 rounded-md flex-grow p-2"
        value={value}
        onChange={(e) => setValue(e.target.value)}
      />
      <button
        type="submit"
        className="p-2 border-[1px] border-black rounded-lg"
      >
        Add Task
      </button>
    </form>
  );
};

export default TodoForm;
