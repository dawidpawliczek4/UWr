import React from "react";

const ToDoElement = ({
  index,
  task,
  tasks,
  setTasks,
}: {
  index: number;
  task: { task: string; done: boolean };
  tasks: { task: string; done: boolean }[];
  setTasks: React.Dispatch<
    React.SetStateAction<{ task: string; done: boolean }[]>
  >;
}) => {
  return (
    <li
      className={`flex flex-row justify-between gap-x-2 bg-gray-200 p-2 w-full rounded-lg ${
        task.done ? "bg-green-200" : ""
      }`}
      key={index}
    >
      <p className={`${task.done ? "line-through" : ""}`}>{task.task}</p>
      <div className="flex flex-row gap-x-4 px-8">
        <input
          type="checkbox"
          className="h-6 w-6 cursor-pointer"
          checked={task.done}
          onChange={(e) => {
            const newTasks = tasks.map((t, i) => {
              if (i === index) {
                return { ...t, done: e.target.checked };
              }
              return t;
            });
            setTasks(newTasks);
          }}
        />
        <button
        className=""
          onClick={() => {
            const newTasks = tasks.filter((_, i) => i !== index);
            setTasks(newTasks);
          }}
        >
          X
        </button>
      </div>
    </li>
  );
};

export default ToDoElement;
