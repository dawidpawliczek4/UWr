import React, { useState } from "react";
import TodoForm from "./components/TodoForm";
import FilterForm from "./components/FilterForm";
import Todos from "./components/Todos";

function App() {
  const [tasks, setTasks] = useState<
    {
      task: string;
      done: boolean;
    }[]
  >([]);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>, value: string) => {
    e.preventDefault();
    if (value === "") return;
    const newTask = { task: value, done: false };
    setTasks([...tasks, newTask]);
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    setSearch(e.target.value);
  };

  const handleFilter = (e: React.ChangeEvent<HTMLSelectElement>) => {
    e.preventDefault();
    setFilter(e.target.value);
  };

  return (
    <div className="max-w-4xl mx-auto bg-gray-100 p-4 flex items-center flex-col gap-y-8 pt-6 mt-8">
      <p className="text-4xl">To Do App</p>
      <TodoForm handleSubmit={handleSubmit} />

      <FilterForm
        search={search}
        filter={filter}
        handleFilter={handleFilter}
        handleSearch={handleSearch}
      />

      <Todos
        tasks={tasks}
        setTasks={setTasks}
        search={search}
        filter={filter}
      />
    </div>
  );
}

export default App;
